const numero = 7;
if (numero % 2 === 0) {
  console.log("Ex 1: O número", numero, "é PAR");
} else {
  console.log("Ex 1: O número", numero, "é ÍMPAR");
}