const idade = 70;
if (idade < 16) {
  console.log("Ex 4: Não-eleitor");
} else if ((idade >= 18) && (idade <= 65)) {
  console.log("Ex 4: Eleitor Obrigatório");
} else {
  console.log("Ex 4: Eleitor Facultativo");
}   